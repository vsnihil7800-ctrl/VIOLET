# Violet AI — Project Reference

Last updated: July 13, 2026

## What this is
This file is a snapshot of the Violet AI project so I (Claude) can pick up context instantly
in a new conversation. Upload this zip + describe what you want changed, and I can go
straight to editing without re-discovering the whole project.

---

## 1. Live URLs

| Piece      | URL |
|------------|-----|
| Frontend (Vercel) | https://violet-rho.vercel.app |
| Backend (Railway) | https://violet-production-adb5.up.railway.app |
| Backend API docs  | https://violet-production-adb5.up.railway.app/api/v1/openapi.json |
| GitHub repo       | https://github.com/vsnihil7800-ctrl/VIOLET (branch: `main`) |

## 2. Hosting / infra

- **Frontend**: Vercel, Root Directory = `frontend`, Framework = Vite, Build = `npm run build`, Output = `dist`
- **Backend**: Railway, Root Directory = `backend`, Docker build (`backend/Dockerfile`)
- **Database**: Neon PostgreSQL (connection string stored as `DATABASE_URL` in Railway Variables — not repeated here for safety, check Railway dashboard)
- **Env vars live in**:
  - Railway → Variables tab: `DATABASE_URL`, `JWT_SECRET_KEY`, `JWT_REFRESH_SECRET_KEY`, `ACCESS_TOKEN_EXPIRE_MINUTES`, `REFRESH_TOKEN_EXPIRE_DAYS`, `CORS_ORIGINS` (=`https://violet-rho.vercel.app`), `PORT` (=`8000`)
  - Vercel → Project Settings → Environment Variables: `VITE_API_URL` (=`https://violet-production-adb5.up.railway.app/api/v1`)

## 3. Tech stack

- **Backend**: FastAPI, SQLAlchemy, Alembic (migrations), PostgreSQL (Neon), JWT auth, Pillow, pytest
- **Frontend**: React 19 + Vite + TypeScript, Tailwind CSS, Zustand (state), React Router v7, TanStack Query, Axios, lucide-react icons

## 4. Project structure

```
VIOLET/
├── backend/
│   ├── app/
│   │   ├── main.py                  # FastAPI app entrypoint, CORS setup, router registration
│   │   ├── core/
│   │   │   ├── config.py            # Settings (env vars), CORS_ORIGINS parsing
│   │   │   ├── database.py          # SQLAlchemy engine/session
│   │   │   └── security.py          # Password hashing, JWT create/verify
│   │   ├── api/
│   │   │   ├── deps.py              # Shared dependencies (get_current_user etc.)
│   │   │   └── endpoints/
│   │   │       ├── auth.py          # register, login, refresh, logout, password reset
│   │   │       ├── users.py
│   │   │       ├── finance.py       # budgets, transactions, debts
│   │   │       ├── investments.py   # trades, watchlist
│   │   │       ├── fitness.py       # workouts, meals
│   │   │       ├── productivity.py
│   │   │       ├── schedule.py
│   │   │       └── ai.py, assistant.py   # AI command center endpoints
│   │   ├── models/                  # SQLAlchemy ORM models (one file per domain)
│   │   ├── schemas/                 # Pydantic request/response schemas
│   │   └── services/
│   │       └── ai_command_center.py # Core AI assistant logic
│   ├── alembic/                     # DB migrations
│   ├── tests/                       # pytest (test_auth.py, test_ai.py)
│   ├── Dockerfile
│   ├── requirements.txt
│   └── railway.json
│
└── frontend/
    ├── src/
    │   ├── pages/                   # One file per screen: Login, Register, Dashboard,
    │   │                            # Finance, Investments, Fitness, Productivity, Schedule,
    │   │                            # Assistant, Vault, Profile, ForgotPassword, ResetPassword
    │   ├── components/
    │   │   ├── Layout/DashboardLayout.tsx
    │   │   ├── Finance/ (BudgetModal, DebtModal, TransactionModal)
    │   │   ├── Investments/ (TradeModal, WatchlistModal)
    │   │   └── Fitness/ (MealModal, WorkoutModal)
    │   ├── services/api.ts          # Axios instance, API_URL from VITE_API_URL
    │   ├── store/authStore.ts       # Zustand auth state
    │   └── context/ThemeContext.tsx
    ├── vercel.json                  # SPA rewrite rules
    └── package.json
```

## 5. Known quirks / things fixed already (don't re-break these)

- Railway needs `PORT=8000` explicitly set — the app defaults to 8080 without it, which breaks Railway's proxy ("Application failed to respond").
- `CORS_ORIGINS` in Railway must exactly match the Vercel production domain (`https://violet-rho.vercel.app`), no trailing slash.
- `backend/railway.json` builder must be `"DOCKERFILE"` (not `"DOCKER"`), and `dockerfilePath` should just be `"Dockerfile"` since Root Directory is already scoped to `backend/`.
- `backend/Dockerfile` copies the whole `backend/` folder into the image, including the local `backend/.env` (no `.dockerignore` yet). Not currently breaking anything since Railway env vars take priority, but worth excluding later.
- `Pillow>=10.0.0` must stay in `requirements.txt` (PIL import needed).

## 6. How to make a change and deploy it

**Everyday code changes (no new env vars, no DB schema change):**
1. Edit files locally (or hand them to Claude to edit)
2. In the project root, open terminal (`C:\Users\vsnih\OneDrive\Desktop\CR\Projects\VIOLET`)
3. Run:
   ```powershell
   git add .
   git commit -m "describe the change"
   git push
   ```
4. Vercel and Railway both auto-redeploy on push to `main` — no manual redeploy needed. Wait ~1-2 min, then check the live site.

**If you add a new environment variable:**
- Add it in Railway (backend) or Vercel (frontend) dashboard manually — pushing code does NOT set env vars.

**If you change a database model:**
```powershell
cd backend
alembic revision --autogenerate -m "describe schema change"
alembic upgrade head
```
Then commit and push as usual. Railway's Docker CMD already runs `alembic upgrade head` on every deploy, so migrations apply automatically in production too — just make sure the migration file itself is committed and pushed.

## 7. How to hand this to Claude for edits

When you want a change:
1. Upload this zip
2. Say what you want changed, e.g. "add a dark mode toggle to the Profile page" or "fix the Vault page, it's showing an error"
3. If it's a bug, also paste the browser console/network error screenshot
4. Claude edits the relevant file(s), explains the change, and gives you the exact `git add / commit / push` commands to run
