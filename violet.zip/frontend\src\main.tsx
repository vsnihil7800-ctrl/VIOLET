import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)

// Register Progressive Web App (PWA) service worker
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("/sw.js")
      .then((reg) => {
        console.log("Violet Service Worker registered successfully:", reg.scope);
      })
      .catch((err) => {
        console.error("Violet Service Worker registration failed:", err);
      });
  });
}
